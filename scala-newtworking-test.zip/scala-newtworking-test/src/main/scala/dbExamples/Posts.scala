package dbExamples

import scalikejdbc._

import java.util.Date

object Posts {
  def writePost(autor:Int, theme:Int, text:String) :Unit = {
    implicit val session = AutoSession
    sql"""insert into Posts(autor, theme, date, text) VALUES($autor, $theme, ${new Date()}, $text)""".update().apply
  }

  def wievPostsfromTheme(id:Int):Seq[Post] = {
    implicit val session = AutoSession
    sql"""select * from Hoomans
        WHERE theme = $id
       """.map(rs =>Post(rs.int("id"), rs.int("autor"), rs.int("theme"), rs.date("date"), rs.string("text"))).list().apply()
  }

  def wievPostsfromAutor(id:Int):Seq[Post] = {
    implicit val session = AutoSession
    sql"""select * from Hoomans
        WHERE autor = $id
       """.map(rs =>Post(rs.int("id"), rs.int("autor"), rs.int("theme"), rs.date("date"), rs.string("text"))).list().apply()
  }




}
case class Post(id:Int, autor:Int, theme:Int, date:Date, text:String)